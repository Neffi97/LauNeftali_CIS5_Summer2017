/* 
 * File:   main.cpp
 * Author: Neftali Lau 
 * Created on July 19, 2017, 8:25 PM
 * Purpose: Create the game of Gwent
 */

//System Libraries
#include <iostream>  //Input - Output Library
#include <cstdlib>   //Srand/Rand
#include <ctime>     //Time
#include <iomanip>   //Format
#include <fstream>   //File I/O
#include <string>
#include <cmath>     //For Power Function
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes
int coinToss(void);
char suit(char);
char face(char);

//Execution begins here
int main(int argc, char** argv) {
    //Setting the Random Number Seed
    srand(static_cast<unsigned int>(time(0)));
    
    //Declare and Initialize variables
    char choice;    //Menu
    ifstream inFile;//Read in the .dat file
    string read;    //For read in .dat file
    int cCall;     //Coin Toss Call
    int randNum=0;  //If/else coin toss
    int power=pow(1,1);//Power function for Project requirement
    string hOrT=""; //Heads or Tails output
    const int SIZE=2;//Array Size
    char unit1,unit2,unit3,unit4,unit5,unit6,unit7,unit8,unit9,unit0;//Units
    unsigned int attck1=0,attck2=0,attck3=0,attck4=0,attck5=0,attck6=0,
            attck7=0,attck8=0,attck9=0,attck0=0;//Attack power
    unsigned int oppRnd1=rand()%9+1,oppRnd2=rand()%9+1,oppRnd3=rand()%9+1,
            oppRnd4=rand()%9+1,oppRnd5=rand()%9+1,oppRnd6=rand()%9+1,
            oppRnd7=rand()%9+1,oppRnd8=rand()%9+1,oppRnd9=rand()%9+1,
            oppRnd0=rand()%9+1;//Random Card for opponent [1,9]
    unsigned int sumP,sumO;//Sum of Player and Sum of Opponent's score
            
    
    //Input data
    
    //Map inputs to outputs or process the data
    //Title Menu
    
    cout<<"Welcome to..."<<endl;
    cout<<endl;
    cout<<"                       *       *      *"<<endl;
    cout<<"                       **     ***    **"<<endl;
    cout<<"                       ***   ****   ***"<<endl;
    cout<<"                       **   ******   **"<<endl;
    cout<<"                       ****************"<<endl;
    cout<<"                       ****************"<<endl;
    cout<<"***********                                            "            <<"*************"<<endl;
    cout<<"**       ** "<<"**      **        ** "<<"******** "<<"**       ** "<<"     **    **"<<endl;
    cout<<"**          "<<"**      **        ** "<<"**       "<<"****     ** "<<"     **      "<<endl;
    cout<<"**          "<<"**      **        ** "<<"**       "<<"** **    ** "<<"     **      "<<endl;
    cout<<"***    **** "<<" **     **       **  "<<"******** "<<"**  **   ** "<<"     **      "<<endl;
    cout<<" **      ** "<<"  **    **      **   "<<"**       "<<"**   **  ** "<<"     **      "<<endl;
    cout<<"   **    ** "<<"   **  ****   **     "<<"**       "<<"**    ** ** "<<"     **      "<<endl;
    cout<<"    **   ** "<<"    ** ** ** **      "<<"**       "<<"**     **** "<<"     **      "<<endl;
    cout<<"      ***** "<<"     **    **        "<<"******** "<<"**      **  "<<"     **      "<<endl;
    cout<<endl;
    cout<<"                    The WITCHER CARD GAME"<<endl;
    cout<<"                    ---------------------"<<endl;
    
    //Loop on the menu
    do{
    
        //Input values
        cout<<"Please Select an Option"<<endl;
        cout<<"Enter '1' to Begin the Game"<<endl;
        cout<<"Enter '2' to View Rules"<<endl;
        cout<<"Enter '3' to know what is currently available in this version "
            <<"of the game, and what is to come in the future."<<endl;
        cout<<"Type any other character to exit"<<endl;
        cin>>choice;

        //Switch to determine the Option
        switch(choice){
            case '1':{
                cout<<"We will flip a coin to see who goes first"<<endl;
                cout<<"Please choose either '1' for Heads or "<<
                      "'2' for Tails..."<<endl;
                cin>>cCall;
                
        //Check to make sure the input was either 1 or 2
                if(cCall==1){
                    cout<<"You chose Heads"<<endl;
                }else if(cCall==2){
                    cout<<"You chose Tails"<<endl;
                }
                else {
                    cout<<"You did not enter either '1' for heads or '2' for"
                        <<" tails, please try again..."<<endl;
                    cin>>cCall;//INFINITE LOOP IF INPUT IS CHARACTER other than integer
                    }
                
                
        //Coin Toss 
            for(int i=1;i<=1;i++){
            randNum=coinToss();
            if(randNum==1)
              hOrT="Result: Heads";
            else
               hOrT="Result: Tails";
             cout<<hOrT<<endl;
            }
                if(randNum==cCall){
                    cout<<"You won the coin toss, you get to go first."<<endl;
                }else{
                    cout<<"You lost the coin toss, you will go second."<<endl;
                }
        //Deal Hand               
                cout<<"This is your hand..."<<endl;
                char card=rand()%28+power;//power=pow(1,1)=1

                cout<<"Card = "<<suit(card)<<face(card)<<endl;

                cout<<"Card = "<<suit(card+2)<<face(card+2)<<endl;

                cout<<"Card = "<<suit(card-2)<<face(card-2)<<endl;

                cout<<"Card = "<<suit(card+4)<<face(card+4)<<endl;

                cout<<"Card = "<<suit(card-4)<<face(card-4)<<endl;

                cout<<"Card = "<<suit(card+6)<<face(card+6)<<endl;

                cout<<"Card = "<<suit(card-6)<<face(card-6)<<endl;

                cout<<"Card = "<<suit(card+8)<<face(card+8)<<endl;

                cout<<"Card = "<<suit(card-8)<<face(card-8)<<endl;

                cout<<"Card = "<<suit(card+10)<<face(card+10)<<endl;

                cout<<"Card = "<<suit(card-10)<<face(card-10)<<endl<<endl;

                
        //Won Coin Toss
            if(randNum==cCall){
                
        //Player: User's Turns        
                for(int x=0;x<20;x++){
                    if(x%2==0){
                        if(x==0){
                            
                cout<<"What type one of your unit cards would you like to"
                    <<" use?"<<endl; 
                cout<<"Please enter 'C' for close combat, 'R' for Ranged,"
                    <<" or 'S' for Siege..."<<endl;
                cout<<"(C/R/S): ";
                cin>>unit1;
                while(unit1!='C'&&unit1!='c'&&unit1!='R'&&unit1!='r'
                        &&unit1!='s'&&unit1!='S'){
                cout<<"You did not enter an appropriate unit"
                    <<" type..."<<endl;
                cout<<"Please enter 'C' for close combat, "
                    <<"'R' for Ranged, or 'S' for Siege..."<<endl;
                cout<<"(C/R/S): ";
                cin>>unit1;

                }
                cout<<"What is the strength of the unit card you'd"
                        <<" like to play?"<<endl;
                cout<<"Please enter the the strength value of the" 
                        <<" unit card written next to the unit type..."
                        <<endl;
                cin>>attck1;
                while(attck1>9||attck1<1){
                cout<<"You did not enter an appropriate strength"
                    <<" value..."<<endl;
                cout<<"Please enter the the strength value of the" 
                        <<" unit card written next to the unit type..."
                        <<endl;
                cin>>attck1;
                }
                        }else if(x==2){
                            
                cout<<"Card = "<<suit(card)<<face(card)<<endl;

                cout<<"Card = "<<suit(card+2)<<face(card+2)<<endl;

                cout<<"Card = "<<suit(card-2)<<face(card-2)<<endl;

                cout<<"Card = "<<suit(card+4)<<face(card+4)<<endl;

                cout<<"Card = "<<suit(card-4)<<face(card-4)<<endl;

                cout<<"Card = "<<suit(card+6)<<face(card+6)<<endl;

                cout<<"Card = "<<suit(card-6)<<face(card-6)<<endl;

                cout<<"Card = "<<suit(card+8)<<face(card+8)<<endl;

                cout<<"Card = "<<suit(card-8)<<face(card-8)<<endl;

                cout<<"Card = "<<suit(card+10)<<face(card+10)<<endl;

                cout<<"Card = "<<suit(card-10)<<face(card-10)<<endl<<endl; 
                           
                            
                 cout<<"What type one of your unit cards would you like to"
                    <<" use?"<<endl; 
                cout<<"Please enter 'C' for close combat, 'R' for Ranged,"
                    <<" or 'S' for Siege..."<<endl;
                cout<<"(C/R/S): ";
                cin>>unit2;
                while(unit2!='C'&&unit2!='c'&&unit2!='R'&&unit2!='r'
                        &&unit2!='s'&&unit2!='S'){
                cout<<"You did not enter an appropriate unit"
                    <<" type..."<<endl;
                cout<<"Please enter 'C' for close combat, "
                    <<"'R' for Ranged, or 'S' for Siege..."<<endl;
                cout<<"(C/R/S): ";
                cin>>unit2;
                }
                
                cout<<"What is the strength of the unit card you'd"
                        <<" like to play?"<<endl;
                cout<<"Please enter the the strength value of the" 
                        <<" unit card written next to the unit type..."
                        <<endl;
                cin>>attck2;
                while(attck2>9||attck2<1){
                cout<<"You did not enter an appropriate strength"
                    <<" value..."<<endl;
                cout<<"Please enter the the strength value of the" 
                        <<" unit card written next to the unit type..."
                        <<endl;
                cin>>attck2;
                }

                        }else if(x==4){
                            
                cout<<"Card = "<<suit(card)<<face(card)<<endl;

                cout<<"Card = "<<suit(card+2)<<face(card+2)<<endl;

                cout<<"Card = "<<suit(card-2)<<face(card-2)<<endl;

                cout<<"Card = "<<suit(card+4)<<face(card+4)<<endl;

                cout<<"Card = "<<suit(card-4)<<face(card-4)<<endl;

                cout<<"Card = "<<suit(card+6)<<face(card+6)<<endl;

                cout<<"Card = "<<suit(card-6)<<face(card-6)<<endl;

                cout<<"Card = "<<suit(card+8)<<face(card+8)<<endl;

                cout<<"Card = "<<suit(card-8)<<face(card-8)<<endl;

                cout<<"Card = "<<suit(card+10)<<face(card+10)<<endl;

                cout<<"Card = "<<suit(card-10)<<face(card-10)<<endl<<endl;
                
                            
                cout<<"What type one of your unit cards would you like to"
                    <<" use?"<<endl; 
                cout<<"Please enter 'C' for close combat, 'R' for Ranged,"
                    <<" or 'S' for Siege..."<<endl;
                cout<<"(C/R/S): ";
                cin>>unit3;
                while(unit3!='C'&&unit3!='c'&&unit3!='R'&&unit3!='r'
                        &&unit3!='s'&&unit3!='S'){
                cout<<"You did not enter an appropriate unit"
                    <<" type..."<<endl;
                cout<<"Please enter 'C' for close combat, "
                    <<"'R' for Ranged, or 'S' for Siege..."<<endl;
                cout<<"(C/R/S): ";
                cin>>unit3;
                }
                
                cout<<"What is the strength of the unit card you'd"
                        <<" like to play?"<<endl;
                cout<<"Please enter the the strength value of the" 
                        <<" unit card written next to the unit type..."
                        <<endl;
                cin>>attck3;
                while(attck3>9||attck3<1){
                cout<<"You did not enter an appropriate strength"
                    <<" value..."<<endl;
                cout<<"Please enter the the strength value of the" 
                        <<" unit card written next to the unit type..."
                        <<endl;
                cin>>attck3;
                }
                    
                        }else if(x==6){
                            
                cout<<"Card = "<<suit(card)<<face(card)<<endl;

                cout<<"Card = "<<suit(card+2)<<face(card+2)<<endl;

                cout<<"Card = "<<suit(card-2)<<face(card-2)<<endl;

                cout<<"Card = "<<suit(card+4)<<face(card+4)<<endl;

                cout<<"Card = "<<suit(card-4)<<face(card-4)<<endl;

                cout<<"Card = "<<suit(card+6)<<face(card+6)<<endl;

                cout<<"Card = "<<suit(card-6)<<face(card-6)<<endl;

                cout<<"Card = "<<suit(card+8)<<face(card+8)<<endl;

                cout<<"Card = "<<suit(card-8)<<face(card-8)<<endl;

                cout<<"Card = "<<suit(card+10)<<face(card+10)<<endl;

                cout<<"Card = "<<suit(card-10)<<face(card-10)<<endl<<endl;
                            
                            
                cout<<"What type one of your unit cards would you like to"
                    <<" use?"<<endl; 
                cout<<"Please enter 'C' for close combat, 'R' for Ranged,"
                    <<" or 'S' for Siege..."<<endl;
                cout<<"(C/R/S): ";
                cin>>unit4;
                while(unit4!='C'&&unit4!='c'&&unit4!='R'&&unit4!='r'
                        &&unit4!='s'&&unit4!='S'){
                cout<<"You did not enter an appropriate unit"
                    <<" type..."<<endl;
                cout<<"Please enter 'C' for close combat, "
                    <<"'R' for Ranged, or 'S' for Siege..."<<endl;
                cout<<"(C/R/S): ";
                cin>>unit4;
                }
                
                cout<<"What is the strength of the unit card you'd"
                        <<" like to play?"<<endl;
                cout<<"Please enter the the strength value of the" 
                        <<" unit card written next to the unit type..."
                        <<endl;
                cin>>attck4;
                while(attck4>9||attck4<1){
                cout<<"You did not enter an appropriate strength"
                    <<" value..."<<endl;
                cout<<"Please enter the the strength value of the" 
                        <<" unit card written next to the unit type..."
                        <<endl;
                cin>>attck4;
                }
                    
                        }else if(x==8){
                            
                cout<<"Card = "<<suit(card)<<face(card)<<endl;

                cout<<"Card = "<<suit(card+2)<<face(card+2)<<endl;

                cout<<"Card = "<<suit(card-2)<<face(card-2)<<endl;

                cout<<"Card = "<<suit(card+4)<<face(card+4)<<endl;

                cout<<"Card = "<<suit(card-4)<<face(card-4)<<endl;

                cout<<"Card = "<<suit(card+6)<<face(card+6)<<endl;

                cout<<"Card = "<<suit(card-6)<<face(card-6)<<endl;

                cout<<"Card = "<<suit(card+8)<<face(card+8)<<endl;

                cout<<"Card = "<<suit(card-8)<<face(card-8)<<endl;

                cout<<"Card = "<<suit(card+10)<<face(card+10)<<endl;

                cout<<"Card = "<<suit(card-10)<<face(card-10)<<endl<<endl;
                            
                            
                cout<<"What type one of your unit cards would you like to"
                    <<" use?"<<endl; 
                cout<<"Please enter 'C' for close combat, 'R' for Ranged,"
                    <<" or 'S' for Siege..."<<endl;
                cout<<"(C/R/S): ";
                cin>>unit5;
                while(unit5!='C'&&unit5!='c'&&unit5!='R'&&unit5!='r'
                        &&unit5!='s'&&unit5!='S'){
                cout<<"You did not enter an appropriate unit"
                    <<" type..."<<endl;
                cout<<"Please enter 'C' for close combat, "
                    <<"'R' for Ranged, or 'S' for Siege..."<<endl;
                cout<<"(C/R/S): ";
                cin>>unit5;
                }
                
                cout<<"What is the strength of the unit card you'd"
                        <<" like to play?"<<endl;
                cout<<"Please enter the the strength value of the" 
                        <<" unit card written next to the unit type..."
                        <<endl;
                cin>>attck5;
                while(attck5>9||attck5<1){
                cout<<"You did not enter an appropriate strength"
                    <<" value..."<<endl;
                cout<<"Please enter the the strength value of the" 
                        <<" unit card written next to the unit type..."
                        <<endl;
                cin>>attck5;
                }
                    
                        }else if(x==10){
                            
                cout<<"Card = "<<suit(card)<<face(card)<<endl;

                cout<<"Card = "<<suit(card+2)<<face(card+2)<<endl;

                cout<<"Card = "<<suit(card-2)<<face(card-2)<<endl;

                cout<<"Card = "<<suit(card+4)<<face(card+4)<<endl;

                cout<<"Card = "<<suit(card-4)<<face(card-4)<<endl;

                cout<<"Card = "<<suit(card+6)<<face(card+6)<<endl;

                cout<<"Card = "<<suit(card-6)<<face(card-6)<<endl;

                cout<<"Card = "<<suit(card+8)<<face(card+8)<<endl;

                cout<<"Card = "<<suit(card-8)<<face(card-8)<<endl;

                cout<<"Card = "<<suit(card+10)<<face(card+10)<<endl;

                cout<<"Card = "<<suit(card-10)<<face(card-10)<<endl<<endl;
                            
                            
                cout<<"What type one of your unit cards would you like to"
                    <<" use?"<<endl; 
                cout<<"Please enter 'C' for close combat, 'R' for Ranged,"
                    <<" or 'S' for Siege..."<<endl;
                cout<<"(C/R/S): ";
                cin>>unit6;
                while(unit6!='C'&&unit6!='c'&&unit6!='R'&&unit6!='r'
                        &&unit6!='s'&&unit6!='S'){
                cout<<"You did not enter an appropriate unit"
                    <<" type..."<<endl;
                cout<<"Please enter 'C' for close combat, "
                    <<"'R' for Ranged, or 'S' for Siege..."<<endl;
                cout<<"(C/R/S): ";
                cin>>unit6;
                }
                
                cout<<"What is the strength of the unit card you'd"
                        <<" like to play?"<<endl;
                cout<<"Please enter the the strength value of the" 
                        <<" unit card written next to the unit type..."
                        <<endl;
                cin>>attck6;
                while(attck6>9||attck6<1){
                cout<<"You did not enter an appropriate strength"
                    <<" value..."<<endl;
                cout<<"Please enter the the strength value of the" 
                        <<" unit card written next to the unit type..."
                        <<endl;
                cin>>attck6;
                }
                    
                        }else if(x==12){
                            
                cout<<"Card = "<<suit(card)<<face(card)<<endl;

                cout<<"Card = "<<suit(card+2)<<face(card+2)<<endl;

                cout<<"Card = "<<suit(card-2)<<face(card-2)<<endl;

                cout<<"Card = "<<suit(card+4)<<face(card+4)<<endl;

                cout<<"Card = "<<suit(card-4)<<face(card-4)<<endl;

                cout<<"Card = "<<suit(card+6)<<face(card+6)<<endl;

                cout<<"Card = "<<suit(card-6)<<face(card-6)<<endl;

                cout<<"Card = "<<suit(card+8)<<face(card+8)<<endl;

                cout<<"Card = "<<suit(card-8)<<face(card-8)<<endl;

                cout<<"Card = "<<suit(card+10)<<face(card+10)<<endl;

                cout<<"Card = "<<suit(card-10)<<face(card-10)<<endl<<endl;
                            
                            
                cout<<"What type one of your unit cards would you like to"
                    <<" use?"<<endl; 
                cout<<"Please enter 'C' for close combat, 'R' for Ranged,"
                    <<" or 'S' for Siege..."<<endl;
                cout<<"(C/R/S): ";
                cin>>unit7;
                while(unit7!='C'&&unit7!='c'&&unit7!='R'&&unit7!='r'
                        &&unit7!='s'&&unit7!='S'){
                cout<<"You did not enter an appropriate unit"
                    <<" type..."<<endl;
                cout<<"Please enter 'C' for close combat, "
                    <<"'R' for Ranged, or 'S' for Siege..."<<endl;
                cout<<"(C/R/S): ";
                cin>>unit7;
                }
                
                cout<<"What is the strength of the unit card you'd"
                        <<" like to play?"<<endl;
                cout<<"Please enter the the strength value of the" 
                        <<" unit card written next to the unit type..."
                        <<endl;
                cin>>attck7;
                while(attck7>9||attck7<1){
                cout<<"You did not enter an appropriate strength"
                    <<" value..."<<endl;
                cout<<"Please enter the the strength value of the" 
                        <<" unit card written next to the unit type..."
                        <<endl;
                cin>>attck7;
                }
                    
                        }else if(x==14){
                            
                cout<<"Card = "<<suit(card)<<face(card)<<endl;

                cout<<"Card = "<<suit(card+2)<<face(card+2)<<endl;

                cout<<"Card = "<<suit(card-2)<<face(card-2)<<endl;

                cout<<"Card = "<<suit(card+4)<<face(card+4)<<endl;

                cout<<"Card = "<<suit(card-4)<<face(card-4)<<endl;

                cout<<"Card = "<<suit(card+6)<<face(card+6)<<endl;

                cout<<"Card = "<<suit(card-6)<<face(card-6)<<endl;

                cout<<"Card = "<<suit(card+8)<<face(card+8)<<endl;

                cout<<"Card = "<<suit(card-8)<<face(card-8)<<endl;

                cout<<"Card = "<<suit(card+10)<<face(card+10)<<endl;

                cout<<"Card = "<<suit(card-10)<<face(card-10)<<endl<<endl;
                            
                            
                cout<<"What type one of your unit cards would you like to"
                    <<" use?"<<endl; 
                cout<<"Please enter 'C' for close combat, 'R' for Ranged,"
                    <<" or 'S' for Siege..."<<endl;
                cout<<"(C/R/S): ";
                cin>>unit8;
                while(unit8!='C'&&unit8!='c'&&unit8!='R'&&unit8!='r'
                        &&unit8!='s'&&unit8!='S'){
                cout<<"You did not enter an appropriate unit"
                    <<" type..."<<endl;
                cout<<"Please enter 'C' for close combat, "
                    <<"'R' for Ranged, or 'S' for Siege..."<<endl;
                cout<<"(C/R/S): ";
                cin>>unit8;
                }
                
                cout<<"What is the strength of the unit card you'd"
                        <<" like to play?"<<endl;
                cout<<"Please enter the the strength value of the" 
                        <<" unit card written next to the unit type..."
                        <<endl;
                cin>>attck8;
                while(attck8>9||attck8<1){
                cout<<"You did not enter an appropriate strength"
                    <<" value..."<<endl;
                cout<<"Please enter the the strength value of the" 
                        <<" unit card written next to the unit type..."
                        <<endl;
                cin>>attck8;
                }
                    
                        }else if(x==16){
                            
                cout<<"Card = "<<suit(card)<<face(card)<<endl;

                cout<<"Card = "<<suit(card+2)<<face(card+2)<<endl;

                cout<<"Card = "<<suit(card-2)<<face(card-2)<<endl;

                cout<<"Card = "<<suit(card+4)<<face(card+4)<<endl;

                cout<<"Card = "<<suit(card-4)<<face(card-4)<<endl;

                cout<<"Card = "<<suit(card+6)<<face(card+6)<<endl;

                cout<<"Card = "<<suit(card-6)<<face(card-6)<<endl;

                cout<<"Card = "<<suit(card+8)<<face(card+8)<<endl;

                cout<<"Card = "<<suit(card-8)<<face(card-8)<<endl;

                cout<<"Card = "<<suit(card+10)<<face(card+10)<<endl;

                cout<<"Card = "<<suit(card-10)<<face(card-10)<<endl<<endl;
                            
                    
                cout<<"What type one of your unit cards would you like to"
                    <<" use?"<<endl; 
                cout<<"Please enter 'C' for close combat, 'R' for Ranged,"
                    <<" or 'S' for Siege..."<<endl;
                cout<<"(C/R/S): ";
                cin>>unit9;
                while(unit9!='C'&&unit9!='c'&&unit9!='R'&&unit9!='r'
                        &&unit9!='s'&&unit9!='S'){
                cout<<"You did not enter an appropriate unit"
                    <<" type..."<<endl;
                cout<<"Please enter 'C' for close combat, "
                    <<"'R' for Ranged, or 'S' for Siege..."<<endl;
                cout<<"(C/R/S): ";
                cin>>unit9;
                }
                
                cout<<"What is the strength of the unit card you'd"
                        <<" like to play?"<<endl;
                cout<<"Please enter the the strength value of the" 
                        <<" unit card written next to the unit type..."
                        <<endl;
                cin>>attck9;
                while(attck9>9||attck9<1){
                cout<<"You did not enter an appropriate strength"
                    <<" value..."<<endl;
                cout<<"Please enter the the strength value of the" 
                        <<" unit card written next to the unit type..."
                        <<endl;
                cin>>attck9;
                }
                            
                        }else if(x==18){
                            
                cout<<"Card = "<<suit(card)<<face(card)<<endl;

                cout<<"Card = "<<suit(card+2)<<face(card+2)<<endl;

                cout<<"Card = "<<suit(card-2)<<face(card-2)<<endl;

                cout<<"Card = "<<suit(card+4)<<face(card+4)<<endl;

                cout<<"Card = "<<suit(card-4)<<face(card-4)<<endl;

                cout<<"Card = "<<suit(card+6)<<face(card+6)<<endl;

                cout<<"Card = "<<suit(card-6)<<face(card-6)<<endl;

                cout<<"Card = "<<suit(card+8)<<face(card+8)<<endl;

                cout<<"Card = "<<suit(card-8)<<face(card-8)<<endl;

                cout<<"Card = "<<suit(card+10)<<face(card+10)<<endl;

                cout<<"Card = "<<suit(card-10)<<face(card-10)<<endl<<endl; 
                           
                            
                cout<<"What type one of your unit cards would you like to"
                    <<" use?"<<endl; 
                cout<<"Please enter 'C' for close combat, 'R' for Ranged,"
                    <<" or 'S' for Siege..."<<endl;
                cout<<"(C/R/S): ";
                cin>>unit0;
                while(unit0!='C'&&unit0!='c'&&unit0!='R'&&unit0!='r'
                        &&unit0!='s'&&unit0!='S'){
                cout<<"You did not enter an appropriate unit"
                    <<" type..."<<endl;
                cout<<"Please enter 'C' for close combat, "
                    <<"'R' for Ranged, or 'S' for Siege..."<<endl;
                cout<<"(C/R/S): ";
                cin>>unit0;
                }
                
                cout<<"What is the strength of the unit card you'd"
                        <<" like to play?"<<endl;
                cout<<"Please enter the the strength value of the" 
                        <<" unit card written next to the unit type..."
                        <<endl;
                cin>>attck0;
                while(attck0>9||attck0<1){
                cout<<"You did not enter an appropriate strength"
                    <<" value..."<<endl;
                cout<<"Please enter the the strength value of the" 
                        <<" unit card written next to the unit type..."
                        <<endl;
                cin>>attck0;
                }
                            
                        }
                    }
                    
            //Player: Computer's Turns
                    else if(x%2==1){
                        
                        cout<<"Opponent:"<<endl;
                        cout<<"Take that!"<<endl;

                    }
                    
    cout<<"_______________________________________________"<<endl;
    cout<<"S:"<<endl;

    if(unit1=='S'||unit1=='s'){
        cout<<"|"<<oppRnd1<<"|";
    }if(unit2=='S'||unit2=='s'){
        cout<<"|"<<oppRnd2<<"|";
    }if(unit3=='S'||unit3=='s'){
        cout<<"|"<<oppRnd3<<"|";
    }if(unit4=='S'||unit4=='s'){
        cout<<"|"<<oppRnd4<<"|";
    }if(unit5=='S'||unit5=='s'){
        cout<<"|"<<oppRnd5<<"|";
    }if(unit6=='S'||unit6=='s'){
        cout<<"|"<<oppRnd6<<"|";
    }if(unit7=='S'||unit7=='s'){
        cout<<"|"<<oppRnd7<<"|";
    }if(unit8=='S'||unit8=='s'){
        cout<<"|"<<oppRnd8<<"|";
    }if(unit9=='S'||unit9=='s'){
        cout<<"|"<<oppRnd9<<"|";
    }if(unit0=='S'||unit0=='s'){
        cout<<"|"<<oppRnd0<<"|";
    }
    
    cout<<"-----------------------------------------------"<<endl;
    cout<<"R:"<<endl;

    if(unit1=='R'||unit1=='r'){
        cout<<"|"<<oppRnd1<<"|";
    }if(unit2=='R'||unit2=='r'){
        cout<<"|"<<oppRnd2<<"|";
    }if(unit3=='R'||unit3=='r'){
        cout<<"|"<<oppRnd3<<"|";
    }if(unit4=='R'||unit4=='r'){
        cout<<"|"<<oppRnd4<<"|";
    }if(unit5=='R'||unit5=='r'){
        cout<<"|"<<oppRnd5<<"|";
    }if(unit6=='R'||unit6=='r'){
        cout<<"|"<<oppRnd6<<"|";
    }if(unit7=='R'||unit7=='r'){
        cout<<"|"<<oppRnd7<<"|";
    }if(unit8=='R'||unit8=='r'){
        cout<<"|"<<oppRnd8<<"|";
    }if(unit9=='R'||unit9=='r'){
        cout<<"|"<<oppRnd9<<"|";
    }if(unit0=='R'||unit0=='r'){
        cout<<"|"<<oppRnd0<<"|";
    }
    
    
    cout<<endl;
    cout<<"-----------------------------------------------"<<endl;
    cout<<"C:"<<endl;

    
    if(unit1=='C'||unit1=='c'){
        cout<<"|"<<oppRnd1<<"|";
    }if(unit2=='C'||unit2=='c'){
        cout<<"|"<<oppRnd2<<"|";
    }if(unit3=='C'||unit3=='c'){
        cout<<"|"<<oppRnd3<<"|";
    }if(unit4=='C'||unit4=='c'){
        cout<<"|"<<oppRnd4<<"|";
    }if(unit5=='C'||unit5=='c'){
        cout<<"|"<<oppRnd5<<"|";
    }if(unit6=='C'||unit6=='c'){
        cout<<"|"<<oppRnd6<<"|";
    }if(unit7=='C'||unit7=='c'){
        cout<<"|"<<oppRnd7<<"|";
    }if(unit8=='C'||unit8=='c'){
        cout<<"|"<<oppRnd8<<"|";
    }if(unit9=='C'||unit9=='c'){
        cout<<"|"<<oppRnd9<<"|";
    }if(unit0=='C'||unit0=='c'){
        cout<<"|"<<oppRnd0<<"|";
    }
    
    
    cout<<endl;
    cout<<"-----------------------------------------------"<<endl;
    cout<<"******************OPPONENT*********************"<<endl;
    cout<<"***********************************************"<<endl;
    cout<<"*******************PLAYER**********************"<<endl;
    cout<<"-----------------------------------------------"<<endl;
    cout<<"C:"<<endl;
    
    if(unit1=='C'||unit1=='c'){
        cout<<"|"<<attck1<<"|";
    }if(unit2=='C'||unit2=='c'){
        cout<<"|"<<attck2<<"|";
    }if(unit3=='C'||unit3=='c'){
        cout<<"|"<<attck3<<"|";
    }if(unit4=='C'||unit4=='c'){
        cout<<"|"<<attck4<<"|";
    }if(unit5=='C'||unit5=='c'){
        cout<<"|"<<attck5<<"|";
    }if(unit6=='C'||unit6=='c'){
        cout<<"|"<<attck6<<"|";
    }if(unit7=='C'||unit7=='c'){
        cout<<"|"<<attck7<<"|";
    }if(unit8=='C'||unit8=='c'){
        cout<<"|"<<attck8<<"|";
    }if(unit9=='C'||unit9=='c'){
        cout<<"|"<<attck9<<"|";
    }if(unit0=='C'||unit0=='c'){
        cout<<"|"<<attck0<<"|";
    }
    
    cout<<endl;
    cout<<"-----------------------------------------------"<<endl;
    cout<<"R:"<<endl;
    
    if(unit1=='R'||unit1=='r'){
        cout<<"|"<<attck1<<"|";
    }if(unit2=='R'||unit2=='r'){
        cout<<"|"<<attck2<<"|";
    }if(unit3=='R'||unit3=='r'){
        cout<<"|"<<attck3<<"|";
    }if(unit4=='R'||unit4=='r'){
        cout<<"|"<<attck4<<"|";
    }if(unit5=='R'||unit5=='r'){
        cout<<"|"<<attck5<<"|";
    }if(unit6=='R'||unit6=='r'){
        cout<<"|"<<attck6<<"|";
    }if(unit7=='R'||unit7=='r'){
        cout<<"|"<<attck7<<"|";
    }if(unit8=='R'||unit8=='r'){
        cout<<"|"<<attck8<<"|";
    }if(unit9=='R'||unit9=='r'){
        cout<<"|"<<attck9<<"|";
    }if(unit0=='R'||unit0=='r'){
        cout<<"|"<<attck0<<"|";
    }
    
    cout<<endl;
    cout<<"-----------------------------------------------"<<endl;
    cout<<"S"<<endl;
    
    if(unit1=='S'||unit1=='s'){
        cout<<"|"<<attck1<<"|";
    }if(unit2=='S'||unit2=='s'){
        cout<<"|"<<attck2<<"|";
    }if(unit3=='S'||unit3=='s'){
        cout<<"|"<<attck3<<"|";
    }if(unit4=='S'||unit4=='s'){
        cout<<"|"<<attck4<<"|";
    }if(unit5=='S'||unit5=='s'){
        cout<<"|"<<attck5<<"|";
    }if(unit6=='S'||unit6=='s'){
        cout<<"|"<<attck6<<"|";
    }if(unit7=='S'||unit7=='s'){
        cout<<"|"<<attck7<<"|";
    }if(unit8=='S'||unit8=='s'){
        cout<<"|"<<attck8<<"|";
    }if(unit9=='S'||unit9=='s'){
        cout<<"|"<<attck9<<"|";
    }if(unit0=='S'||unit0=='s'){
        cout<<"|"<<attck0<<"|";
    }
    
    cout<<endl;
    cout<<"_______________________________________________"<<endl;
                    
                }
                
        //If Lose Coin Toss        
            }else if(randNum!=cCall){
                
                
                
        //Player: User's Turns        
                for(int x=0;x<20;x++){
                    if(x%2==1){
                        if(x==1){
                            
                cout<<"What type one of your unit cards would you like to"
                    <<" use?"<<endl; 
                cout<<"Please enter 'C' for close combat, 'R' for Ranged,"
                    <<" or 'S' for Siege..."<<endl;
                cout<<"(C/R/S): ";
                cin>>unit1;
                while(unit1!='C'&&unit1!='c'&&unit1!='R'&&unit1!='r'
                        &&unit1!='s'&&unit1!='S'){
                cout<<"You did not enter an appropriate unit"
                    <<" type..."<<endl;
                cout<<"Please enter 'C' for close combat, "
                    <<"'R' for Ranged, or 'S' for Siege..."<<endl;
                cout<<"(C/R/S): ";
                cin>>unit1;

                }
                cout<<"What is the strength of the unit card you'd"
                        <<" like to play?"<<endl;
                cout<<"Please enter the the strength value of the" 
                        <<" unit card written next to the unit type..."
                        <<endl;
                cin>>attck1;
                while(attck1>9||attck1<1){
                cout<<"You did not enter an appropriate strength"
                    <<" value..."<<endl;
                cout<<"Please enter the the strength value of the" 
                        <<" unit card written next to the unit type..."
                        <<endl;
                cin>>attck1;
                }
                        }else if(x==3){
                            
                cout<<"Card = "<<suit(card)<<face(card)<<endl;

                cout<<"Card = "<<suit(card+2)<<face(card+2)<<endl;

                cout<<"Card = "<<suit(card-2)<<face(card-2)<<endl;

                cout<<"Card = "<<suit(card+4)<<face(card+4)<<endl;

                cout<<"Card = "<<suit(card-4)<<face(card-4)<<endl;

                cout<<"Card = "<<suit(card+6)<<face(card+6)<<endl;

                cout<<"Card = "<<suit(card-6)<<face(card-6)<<endl;

                cout<<"Card = "<<suit(card+8)<<face(card+8)<<endl;

                cout<<"Card = "<<suit(card-8)<<face(card-8)<<endl;

                cout<<"Card = "<<suit(card+10)<<face(card+10)<<endl;

                cout<<"Card = "<<suit(card-10)<<face(card-10)<<endl<<endl; 
                           
                            
                 cout<<"What type one of your unit cards would you like to"
                    <<" use?"<<endl; 
                cout<<"Please enter 'C' for close combat, 'R' for Ranged,"
                    <<" or 'S' for Siege..."<<endl;
                cout<<"(C/R/S): ";
                cin>>unit2;
                while(unit2!='C'&&unit2!='c'&&unit2!='R'&&unit2!='r'
                        &&unit2!='s'&&unit2!='S'){
                cout<<"You did not enter an appropriate unit"
                    <<" type..."<<endl;
                cout<<"Please enter 'C' for close combat, "
                    <<"'R' for Ranged, or 'S' for Siege..."<<endl;
                cout<<"(C/R/S): ";
                cin>>unit2;
                }
                
                cout<<"What is the strength of the unit card you'd"
                        <<" like to play?"<<endl;
                cout<<"Please enter the the strength value of the" 
                        <<" unit card written next to the unit type..."
                        <<endl;
                cin>>attck2;
                while(attck2>9||attck2<1){
                cout<<"You did not enter an appropriate strength"
                    <<" value..."<<endl;
                cout<<"Please enter the the strength value of the" 
                        <<" unit card written next to the unit type..."
                        <<endl;
                cin>>attck2;
                }

                        }else if(x==5){
                            
                cout<<"Card = "<<suit(card)<<face(card)<<endl;

                cout<<"Card = "<<suit(card+2)<<face(card+2)<<endl;

                cout<<"Card = "<<suit(card-2)<<face(card-2)<<endl;

                cout<<"Card = "<<suit(card+4)<<face(card+4)<<endl;

                cout<<"Card = "<<suit(card-4)<<face(card-4)<<endl;

                cout<<"Card = "<<suit(card+6)<<face(card+6)<<endl;

                cout<<"Card = "<<suit(card-6)<<face(card-6)<<endl;

                cout<<"Card = "<<suit(card+8)<<face(card+8)<<endl;

                cout<<"Card = "<<suit(card-8)<<face(card-8)<<endl;

                cout<<"Card = "<<suit(card+10)<<face(card+10)<<endl;

                cout<<"Card = "<<suit(card-10)<<face(card-10)<<endl<<endl;
                
                            
                cout<<"What type one of your unit cards would you like to"
                    <<" use?"<<endl; 
                cout<<"Please enter 'C' for close combat, 'R' for Ranged,"
                    <<" or 'S' for Siege..."<<endl;
                cout<<"(C/R/S): ";
                cin>>unit3;
                while(unit3!='C'&&unit3!='c'&&unit3!='R'&&unit3!='r'
                        &&unit3!='s'&&unit3!='S'){
                cout<<"You did not enter an appropriate unit"
                    <<" type..."<<endl;
                cout<<"Please enter 'C' for close combat, "
                    <<"'R' for Ranged, or 'S' for Siege..."<<endl;
                cout<<"(C/R/S): ";
                cin>>unit3;
                }
                
                cout<<"What is the strength of the unit card you'd"
                        <<" like to play?"<<endl;
                cout<<"Please enter the the strength value of the" 
                        <<" unit card written next to the unit type..."
                        <<endl;
                cin>>attck3;
                while(attck3>9||attck3<1){
                cout<<"You did not enter an appropriate strength"
                    <<" value..."<<endl;
                cout<<"Please enter the the strength value of the" 
                        <<" unit card written next to the unit type..."
                        <<endl;
                cin>>attck3;
                }
                    
                        }else if(x==7){
                            
                cout<<"Card = "<<suit(card)<<face(card)<<endl;

                cout<<"Card = "<<suit(card+2)<<face(card+2)<<endl;

                cout<<"Card = "<<suit(card-2)<<face(card-2)<<endl;

                cout<<"Card = "<<suit(card+4)<<face(card+4)<<endl;

                cout<<"Card = "<<suit(card-4)<<face(card-4)<<endl;

                cout<<"Card = "<<suit(card+6)<<face(card+6)<<endl;

                cout<<"Card = "<<suit(card-6)<<face(card-6)<<endl;

                cout<<"Card = "<<suit(card+8)<<face(card+8)<<endl;

                cout<<"Card = "<<suit(card-8)<<face(card-8)<<endl;

                cout<<"Card = "<<suit(card+10)<<face(card+10)<<endl;

                cout<<"Card = "<<suit(card-10)<<face(card-10)<<endl<<endl;
                            
                            
                cout<<"What type one of your unit cards would you like to"
                    <<" use?"<<endl; 
                cout<<"Please enter 'C' for close combat, 'R' for Ranged,"
                    <<" or 'S' for Siege..."<<endl;
                cout<<"(C/R/S): ";
                cin>>unit4;
                while(unit4!='C'&&unit4!='c'&&unit4!='R'&&unit4!='r'
                        &&unit4!='s'&&unit4!='S'){
                cout<<"You did not enter an appropriate unit"
                    <<" type..."<<endl;
                cout<<"Please enter 'C' for close combat, "
                    <<"'R' for Ranged, or 'S' for Siege..."<<endl;
                cout<<"(C/R/S): ";
                cin>>unit4;
                }
                
                cout<<"What is the strength of the unit card you'd"
                        <<" like to play?"<<endl;
                cout<<"Please enter the the strength value of the" 
                        <<" unit card written next to the unit type..."
                        <<endl;
                cin>>attck4;
                while(attck4>9||attck4<1){
                cout<<"You did not enter an appropriate strength"
                    <<" value..."<<endl;
                cout<<"Please enter the the strength value of the" 
                        <<" unit card written next to the unit type..."
                        <<endl;
                cin>>attck4;
                }
                    
                        }else if(x==9){
                            
                cout<<"Card = "<<suit(card)<<face(card)<<endl;

                cout<<"Card = "<<suit(card+2)<<face(card+2)<<endl;

                cout<<"Card = "<<suit(card-2)<<face(card-2)<<endl;

                cout<<"Card = "<<suit(card+4)<<face(card+4)<<endl;

                cout<<"Card = "<<suit(card-4)<<face(card-4)<<endl;

                cout<<"Card = "<<suit(card+6)<<face(card+6)<<endl;

                cout<<"Card = "<<suit(card-6)<<face(card-6)<<endl;

                cout<<"Card = "<<suit(card+8)<<face(card+8)<<endl;

                cout<<"Card = "<<suit(card-8)<<face(card-8)<<endl;

                cout<<"Card = "<<suit(card+10)<<face(card+10)<<endl;

                cout<<"Card = "<<suit(card-10)<<face(card-10)<<endl<<endl;
                            
                            
                cout<<"What type one of your unit cards would you like to"
                    <<" use?"<<endl; 
                cout<<"Please enter 'C' for close combat, 'R' for Ranged,"
                    <<" or 'S' for Siege..."<<endl;
                cout<<"(C/R/S): ";
                cin>>unit5;
                while(unit5!='C'&&unit5!='c'&&unit5!='R'&&unit5!='r'
                        &&unit5!='s'&&unit5!='S'){
                cout<<"You did not enter an appropriate unit"
                    <<" type..."<<endl;
                cout<<"Please enter 'C' for close combat, "
                    <<"'R' for Ranged, or 'S' for Siege..."<<endl;
                cout<<"(C/R/S): ";
                cin>>unit5;
                }
                
                cout<<"What is the strength of the unit card you'd"
                        <<" like to play?"<<endl;
                cout<<"Please enter the the strength value of the" 
                        <<" unit card written next to the unit type..."
                        <<endl;
                cin>>attck5;
                while(attck5>9||attck5<1){
                cout<<"You did not enter an appropriate strength"
                    <<" value..."<<endl;
                cout<<"Please enter the the strength value of the" 
                        <<" unit card written next to the unit type..."
                        <<endl;
                cin>>attck5;
                }
                    
                        }else if(x==11){
                            
                cout<<"Card = "<<suit(card)<<face(card)<<endl;

                cout<<"Card = "<<suit(card+2)<<face(card+2)<<endl;

                cout<<"Card = "<<suit(card-2)<<face(card-2)<<endl;

                cout<<"Card = "<<suit(card+4)<<face(card+4)<<endl;

                cout<<"Card = "<<suit(card-4)<<face(card-4)<<endl;

                cout<<"Card = "<<suit(card+6)<<face(card+6)<<endl;

                cout<<"Card = "<<suit(card-6)<<face(card-6)<<endl;

                cout<<"Card = "<<suit(card+8)<<face(card+8)<<endl;

                cout<<"Card = "<<suit(card-8)<<face(card-8)<<endl;

                cout<<"Card = "<<suit(card+10)<<face(card+10)<<endl;

                cout<<"Card = "<<suit(card-10)<<face(card-10)<<endl<<endl;
                            
                            
                cout<<"What type one of your unit cards would you like to"
                    <<" use?"<<endl; 
                cout<<"Please enter 'C' for close combat, 'R' for Ranged,"
                    <<" or 'S' for Siege..."<<endl;
                cout<<"(C/R/S): ";
                cin>>unit6;
                while(unit6!='C'&&unit6!='c'&&unit6!='R'&&unit6!='r'
                        &&unit6!='s'&&unit6!='S'){
                cout<<"You did not enter an appropriate unit"
                    <<" type..."<<endl;
                cout<<"Please enter 'C' for close combat, "
                    <<"'R' for Ranged, or 'S' for Siege..."<<endl;
                cout<<"(C/R/S): ";
                cin>>unit6;
                }
                
                cout<<"What is the strength of the unit card you'd"
                        <<" like to play?"<<endl;
                cout<<"Please enter the the strength value of the" 
                        <<" unit card written next to the unit type..."
                        <<endl;
                cin>>attck6;
                while(attck6>9||attck6<1){
                cout<<"You did not enter an appropriate strength"
                    <<" value..."<<endl;
                cout<<"Please enter the the strength value of the" 
                        <<" unit card written next to the unit type..."
                        <<endl;
                cin>>attck6;
                }
                    
                        }else if(x==13){
                            
                cout<<"Card = "<<suit(card)<<face(card)<<endl;

                cout<<"Card = "<<suit(card+2)<<face(card+2)<<endl;

                cout<<"Card = "<<suit(card-2)<<face(card-2)<<endl;

                cout<<"Card = "<<suit(card+4)<<face(card+4)<<endl;

                cout<<"Card = "<<suit(card-4)<<face(card-4)<<endl;

                cout<<"Card = "<<suit(card+6)<<face(card+6)<<endl;

                cout<<"Card = "<<suit(card-6)<<face(card-6)<<endl;

                cout<<"Card = "<<suit(card+8)<<face(card+8)<<endl;

                cout<<"Card = "<<suit(card-8)<<face(card-8)<<endl;

                cout<<"Card = "<<suit(card+10)<<face(card+10)<<endl;

                cout<<"Card = "<<suit(card-10)<<face(card-10)<<endl<<endl;
                            
                            
                cout<<"What type one of your unit cards would you like to"
                    <<" use?"<<endl; 
                cout<<"Please enter 'C' for close combat, 'R' for Ranged,"
                    <<" or 'S' for Siege..."<<endl;
                cout<<"(C/R/S): ";
                cin>>unit7;
                while(unit7!='C'&&unit7!='c'&&unit7!='R'&&unit7!='r'
                        &&unit7!='s'&&unit7!='S'){
                cout<<"You did not enter an appropriate unit"
                    <<" type..."<<endl;
                cout<<"Please enter 'C' for close combat, "
                    <<"'R' for Ranged, or 'S' for Siege..."<<endl;
                cout<<"(C/R/S): ";
                cin>>unit7;
                }
                
                cout<<"What is the strength of the unit card you'd"
                        <<" like to play?"<<endl;
                cout<<"Please enter the the strength value of the" 
                        <<" unit card written next to the unit type..."
                        <<endl;
                cin>>attck7;
                while(attck7>9||attck7<1){
                cout<<"You did not enter an appropriate strength"
                    <<" value..."<<endl;
                cout<<"Please enter the the strength value of the" 
                        <<" unit card written next to the unit type..."
                        <<endl;
                cin>>attck7;
                }
                    
                        }else if(x==15){
                            
                cout<<"Card = "<<suit(card)<<face(card)<<endl;

                cout<<"Card = "<<suit(card+2)<<face(card+2)<<endl;

                cout<<"Card = "<<suit(card-2)<<face(card-2)<<endl;

                cout<<"Card = "<<suit(card+4)<<face(card+4)<<endl;

                cout<<"Card = "<<suit(card-4)<<face(card-4)<<endl;

                cout<<"Card = "<<suit(card+6)<<face(card+6)<<endl;

                cout<<"Card = "<<suit(card-6)<<face(card-6)<<endl;

                cout<<"Card = "<<suit(card+8)<<face(card+8)<<endl;

                cout<<"Card = "<<suit(card-8)<<face(card-8)<<endl;

                cout<<"Card = "<<suit(card+10)<<face(card+10)<<endl;

                cout<<"Card = "<<suit(card-10)<<face(card-10)<<endl<<endl;
                            
                            
                cout<<"What type one of your unit cards would you like to"
                    <<" use?"<<endl; 
                cout<<"Please enter 'C' for close combat, 'R' for Ranged,"
                    <<" or 'S' for Siege..."<<endl;
                cout<<"(C/R/S): ";
                cin>>unit8;
                while(unit8!='C'&&unit8!='c'&&unit8!='R'&&unit8!='r'
                        &&unit8!='s'&&unit8!='S'){
                cout<<"You did not enter an appropriate unit"
                    <<" type..."<<endl;
                cout<<"Please enter 'C' for close combat, "
                    <<"'R' for Ranged, or 'S' for Siege..."<<endl;
                cout<<"(C/R/S): ";
                cin>>unit8;
                }
                
                cout<<"What is the strength of the unit card you'd"
                        <<" like to play?"<<endl;
                cout<<"Please enter the the strength value of the" 
                        <<" unit card written next to the unit type..."
                        <<endl;
                cin>>attck8;
                while(attck8>9||attck8<1){
                cout<<"You did not enter an appropriate strength"
                    <<" value..."<<endl;
                cout<<"Please enter the the strength value of the" 
                        <<" unit card written next to the unit type..."
                        <<endl;
                cin>>attck8;
                }
                    
                        }else if(x==17){
                            
                cout<<"Card = "<<suit(card)<<face(card)<<endl;

                cout<<"Card = "<<suit(card+2)<<face(card+2)<<endl;

                cout<<"Card = "<<suit(card-2)<<face(card-2)<<endl;

                cout<<"Card = "<<suit(card+4)<<face(card+4)<<endl;

                cout<<"Card = "<<suit(card-4)<<face(card-4)<<endl;

                cout<<"Card = "<<suit(card+6)<<face(card+6)<<endl;

                cout<<"Card = "<<suit(card-6)<<face(card-6)<<endl;

                cout<<"Card = "<<suit(card+8)<<face(card+8)<<endl;

                cout<<"Card = "<<suit(card-8)<<face(card-8)<<endl;

                cout<<"Card = "<<suit(card+10)<<face(card+10)<<endl;

                cout<<"Card = "<<suit(card-10)<<face(card-10)<<endl<<endl;
                            
                    
                cout<<"What type one of your unit cards would you like to"
                    <<" use?"<<endl; 
                cout<<"Please enter 'C' for close combat, 'R' for Ranged,"
                    <<" or 'S' for Siege..."<<endl;
                cout<<"(C/R/S): ";
                cin>>unit9;
                while(unit9!='C'&&unit9!='c'&&unit9!='R'&&unit9!='r'
                        &&unit9!='s'&&unit9!='S'){
                cout<<"You did not enter an appropriate unit"
                    <<" type..."<<endl;
                cout<<"Please enter 'C' for close combat, "
                    <<"'R' for Ranged, or 'S' for Siege..."<<endl;
                cout<<"(C/R/S): ";
                cin>>unit9;
                }
                
                cout<<"What is the strength of the unit card you'd"
                        <<" like to play?"<<endl;
                cout<<"Please enter the the strength value of the" 
                        <<" unit card written next to the unit type..."
                        <<endl;
                cin>>attck9;
                while(attck9>9||attck9<1){
                cout<<"You did not enter an appropriate strength"
                    <<" value..."<<endl;
                cout<<"Please enter the the strength value of the" 
                        <<" unit card written next to the unit type..."
                        <<endl;
                cin>>attck9;
                }
                            
                        }else if(x==19){
                            
                cout<<"Card = "<<suit(card)<<face(card)<<endl;

                cout<<"Card = "<<suit(card+2)<<face(card+2)<<endl;

                cout<<"Card = "<<suit(card-2)<<face(card-2)<<endl;

                cout<<"Card = "<<suit(card+4)<<face(card+4)<<endl;

                cout<<"Card = "<<suit(card-4)<<face(card-4)<<endl;

                cout<<"Card = "<<suit(card+6)<<face(card+6)<<endl;

                cout<<"Card = "<<suit(card-6)<<face(card-6)<<endl;

                cout<<"Card = "<<suit(card+8)<<face(card+8)<<endl;

                cout<<"Card = "<<suit(card-8)<<face(card-8)<<endl;

                cout<<"Card = "<<suit(card+10)<<face(card+10)<<endl;

                cout<<"Card = "<<suit(card-10)<<face(card-10)<<endl<<endl; 
                           
                            
                cout<<"What type one of your unit cards would you like to"
                    <<" use?"<<endl; 
                cout<<"Please enter 'C' for close combat, 'R' for Ranged,"
                    <<" or 'S' for Siege..."<<endl;
                cout<<"(C/R/S): ";
                cin>>unit0;
                while(unit0!='C'&&unit0!='c'&&unit0!='R'&&unit0!='r'
                        &&unit0!='s'&&unit0!='S'){
                cout<<"You did not enter an appropriate unit"
                    <<" type..."<<endl;
                cout<<"Please enter 'C' for close combat, "
                    <<"'R' for Ranged, or 'S' for Siege..."<<endl;
                cout<<"(C/R/S): ";
                cin>>unit0;
                }
                
                cout<<"What is the strength of the unit card you'd"
                        <<" like to play?"<<endl;
                cout<<"Please enter the the strength value of the" 
                        <<" unit card written next to the unit type..."
                        <<endl;
                cin>>attck0;
                while(attck0>9||attck0<1){
                cout<<"You did not enter an appropriate strength"
                    <<" value..."<<endl;
                cout<<"Please enter the the strength value of the" 
                        <<" unit card written next to the unit type..."
                        <<endl;
                cin>>attck0;
                }
                            
                        }
                    }
                    
            //Player: Computer's Turns
                    else if(x%2==0){
                        
                        cout<<"Opponent:"<<endl;
                        cout<<"Take that!"<<endl;

                    }
                    
    cout<<"_______________________________________________"<<endl;
    cout<<"S:"<<endl;

    if(unit1=='S'||unit1=='s'){
        cout<<"|"<<oppRnd1<<"|";
    }if(unit2=='S'||unit2=='s'){
        cout<<"|"<<oppRnd2<<"|";
    }if(unit3=='S'||unit3=='s'){
        cout<<"|"<<oppRnd3<<"|";
    }if(unit4=='S'||unit4=='s'){
        cout<<"|"<<oppRnd4<<"|";
    }if(unit5=='S'||unit5=='s'){
        cout<<"|"<<oppRnd5<<"|";
    }if(unit6=='S'||unit6=='s'){
        cout<<"|"<<oppRnd6<<"|";
    }if(unit7=='S'||unit7=='s'){
        cout<<"|"<<oppRnd7<<"|";
    }if(unit8=='S'||unit8=='s'){
        cout<<"|"<<oppRnd8<<"|";
    }if(unit9=='S'||unit9=='s'){
        cout<<"|"<<oppRnd9<<"|";
    }if(unit0=='S'||unit0=='s'){
        cout<<"|"<<oppRnd0<<"|";
    }
    
    cout<<"-----------------------------------------------"<<endl;
    cout<<"R:"<<endl;

    if(unit1=='R'||unit1=='r'){
        cout<<"|"<<oppRnd1<<"|";
    }if(unit2=='R'||unit2=='r'){
        cout<<"|"<<oppRnd2<<"|";
    }if(unit3=='R'||unit3=='r'){
        cout<<"|"<<oppRnd3<<"|";
    }if(unit4=='R'||unit4=='r'){
        cout<<"|"<<oppRnd4<<"|";
    }if(unit5=='R'||unit5=='r'){
        cout<<"|"<<oppRnd5<<"|";
    }if(unit6=='R'||unit6=='r'){
        cout<<"|"<<oppRnd6<<"|";
    }if(unit7=='R'||unit7=='r'){
        cout<<"|"<<oppRnd7<<"|";
    }if(unit8=='R'||unit8=='r'){
        cout<<"|"<<oppRnd8<<"|";
    }if(unit9=='R'||unit9=='r'){
        cout<<"|"<<oppRnd9<<"|";
    }if(unit0=='R'||unit0=='r'){
        cout<<"|"<<oppRnd0<<"|";
    }
    
    
    cout<<endl;
    cout<<"-----------------------------------------------"<<endl;
    cout<<"C:"<<endl;

    
    if(unit1=='C'||unit1=='c'){
        cout<<"|"<<oppRnd1<<"|";
    }if(unit2=='C'||unit2=='c'){
        cout<<"|"<<oppRnd2<<"|";
    }if(unit3=='C'||unit3=='c'){
        cout<<"|"<<oppRnd3<<"|";
    }if(unit4=='C'||unit4=='c'){
        cout<<"|"<<oppRnd4<<"|";
    }if(unit5=='C'||unit5=='c'){
        cout<<"|"<<oppRnd5<<"|";
    }if(unit6=='C'||unit6=='c'){
        cout<<"|"<<oppRnd6<<"|";
    }if(unit7=='C'||unit7=='c'){
        cout<<"|"<<oppRnd7<<"|";
    }if(unit8=='C'||unit8=='c'){
        cout<<"|"<<oppRnd8<<"|";
    }if(unit9=='C'||unit9=='c'){
        cout<<"|"<<oppRnd9<<"|";
    }if(unit0=='C'||unit0=='c'){
        cout<<"|"<<oppRnd0<<"|";
    }
    
    
    cout<<endl;
    cout<<"-----------------------------------------------"<<endl;
    cout<<"******************OPPONENT*********************"<<endl;
    cout<<"***********************************************"<<endl;
    cout<<"*******************PLAYER**********************"<<endl;
    cout<<"-----------------------------------------------"<<endl;
    cout<<"C:"<<endl;
    
    if(unit1=='C'||unit1=='c'){
        cout<<"|"<<attck1<<"|";
    }if(unit2=='C'||unit2=='c'){
        cout<<"|"<<attck2<<"|";
    }if(unit3=='C'||unit3=='c'){
        cout<<"|"<<attck3<<"|";
    }if(unit4=='C'||unit4=='c'){
        cout<<"|"<<attck4<<"|";
    }if(unit5=='C'||unit5=='c'){
        cout<<"|"<<attck5<<"|";
    }if(unit6=='C'||unit6=='c'){
        cout<<"|"<<attck6<<"|";
    }if(unit7=='C'||unit7=='c'){
        cout<<"|"<<attck7<<"|";
    }if(unit8=='C'||unit8=='c'){
        cout<<"|"<<attck8<<"|";
    }if(unit9=='C'||unit9=='c'){
        cout<<"|"<<attck9<<"|";
    }if(unit0=='C'||unit0=='c'){
        cout<<"|"<<attck0<<"|";
    }
    
    cout<<endl;
    cout<<"-----------------------------------------------"<<endl;
    cout<<"R:"<<endl;
    
    if(unit1=='R'||unit1=='r'){
        cout<<"|"<<attck1<<"|";
    }if(unit2=='R'||unit2=='r'){
        cout<<"|"<<attck2<<"|";
    }if(unit3=='R'||unit3=='r'){
        cout<<"|"<<attck3<<"|";
    }if(unit4=='R'||unit4=='r'){
        cout<<"|"<<attck4<<"|";
    }if(unit5=='R'||unit5=='r'){
        cout<<"|"<<attck5<<"|";
    }if(unit6=='R'||unit6=='r'){
        cout<<"|"<<attck6<<"|";
    }if(unit7=='R'||unit7=='r'){
        cout<<"|"<<attck7<<"|";
    }if(unit8=='R'||unit8=='r'){
        cout<<"|"<<attck8<<"|";
    }if(unit9=='R'||unit9=='r'){
        cout<<"|"<<attck9<<"|";
    }if(unit0=='R'||unit0=='r'){
        cout<<"|"<<attck0<<"|";
    }
    
    cout<<endl;
    cout<<"-----------------------------------------------"<<endl;
    cout<<"S"<<endl;
    
    if(unit1=='S'||unit1=='s'){
        cout<<"|"<<attck1<<"|";
    }if(unit2=='S'||unit2=='s'){
        cout<<"|"<<attck2<<"|";
    }if(unit3=='S'||unit3=='s'){
        cout<<"|"<<attck3<<"|";
    }if(unit4=='S'||unit4=='s'){
        cout<<"|"<<attck4<<"|";
    }if(unit5=='S'||unit5=='s'){
        cout<<"|"<<attck5<<"|";
    }if(unit6=='S'||unit6=='s'){
        cout<<"|"<<attck6<<"|";
    }if(unit7=='S'||unit7=='s'){
        cout<<"|"<<attck7<<"|";
    }if(unit8=='S'||unit8=='s'){
        cout<<"|"<<attck8<<"|";
    }if(unit9=='S'||unit9=='s'){
        cout<<"|"<<attck9<<"|";
    }if(unit0=='S'||unit0=='s'){
        cout<<"|"<<attck0<<"|";
    }
    
    cout<<endl;
    cout<<"_______________________________________________"<<endl;
                    
                }
                     
            }
        
        //Sum the Total of Both Scores
                
            sumO=oppRnd1+oppRnd2+oppRnd3+oppRnd4+oppRnd5+oppRnd6+oppRnd7+
                    oppRnd8+oppRnd9+oppRnd0;
            sumP=attck1+attck2+attck3+attck4+attck5+attck6+attck7+attck8+
                    attck9+attck0;
            cout<<"Opponent's Total: "<<sumO<<endl;
            cout<<"Your total: "<<sumP<<endl;
            
        
        //Output the Winner    
            
            if(sumP>sumO){
                cout<<"*****************************"<<endl;
                cout<<"*Congratulations! You Won!!*"<<endl;
                cout<<"*****************************"<<endl;
            }else if(sumP<sumO){
                cout<<"Sorry, you did not win!"<<endl;
            }else if(sumP==sumO){
                cout<<"It's a Tie!!!"<<endl;
            }  
                  
                break;
            }
            case '2':{
                inFile.open("gRules.dat");//File containing rules
                
                while(inFile>>read){
                cout<<read<<" ";//ASK ABOUT HOW TO MAKE EACH NUMBER SEPARATE
                }
                
                inFile.close();
                
               
                break;
            }
            case '3':{
                cout<<"This version of the game contains the main unit cards"
                    <<" and the strength values they hold."<<endl;
                cout<<"At the moment, you're able to only play one round of"
                    <<" the match, but please look forward to the next update"
                    <<" which will contain the other features of the game."<<endl;
                cout<<"This includes the some of the special unit cards and "
                    <<"the weather effect cards."<<endl;
            }
            default:
                cout<<"You are exiting the Game. Thank you for playing!"<<endl;
        }
    }while(choice>='1'&&choice<='3');
    
    //Output the transformed data
    
    //Exit stage right!
    return 0;
}

char face(char card){
    switch(card%13){
        case 1:return '1';
        case 2:return '2';
        case 3:return '3';
        case 4:return '4';
        case 5:return '5';
        case 6:return '6';
        case 7:return '7';
        case 8:return '8';
        default:return '9';
    }
}

char suit(char card){
    if(card<=9)return 'C';//c -> Close Combat
    if(card<=18)return 'R';//r -> Ranged
                return 'S';//s -> Siege
}

int coinToss(void){
    int fRndNum;//Function Random Number
    fRndNum=1+rand()%2;
    return fRndNum;
}