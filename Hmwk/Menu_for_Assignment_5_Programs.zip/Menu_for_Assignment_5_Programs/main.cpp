
/*
 * File:   main.cpp
 * Author: Neftali Lau
 *
 * Created on July 10, 2017, 11:48 PM
 * Purpose: Menu for Assignment 4
 */
//System Libraries 
#include <iostream> //Input/Output Library 
#include <cmath>    //Power Function 
#include <iomanip>  //Format Libary
#include <cstdlib>
#include <ctime>
#include <string.h>
using namespace std; //Libraries using namespace standard 

 //User Libraries 
 
 //Global Constants-> Physics/Math/Conversions
float grav=9.8;//Gravity in m/s^2
const int CNVPERC=100;//Conversion to Percentage
 
 //Function Prototypes
void calculateRetail(float,float);
float getSales(string);
void findHighest(float,float,float,float);
int getNumAccidents(string);
void findLowest(int,int,int,int,int);
float fallingDistance(int);
float kineticEnergy(int,int);
float celsius (float);
int coinToss(void);
float fValue1(float,float,int);//Power
float fValue2(float,float,int);//Exp-Log
float fValue3(float,float,int);//For-Loop
float fValue4(float,float,int);//Recursion
int   fValue5(float,float,int,float&);//Pass by Reference, Also Static Variable
float fValue1(float,float,float);//Power Overridden using float Years
float fValue6(float,float,int=12);//Power Defaulted Years
bool isLpYr(int);
char getCent(int);
char getYear(int);
char getMnth(string,int);
char getDay(string);
 
//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    char choice;
    
    //Loop on the menu
    do{
    
        //Input values
        cout<<"Choose from the list"<<endl;
        cout<<"Type 1 for Calculate Retail Price Problem"<<endl;
        cout<<"Type 2 for Winning Division Problem"<<endl;
        cout<<"Type 3 for Safest Driving Area Problem"<<endl;
        cout<<"Type 4 for Falling Distance Problem"<<endl;
        cout<<"Type 5 for Kinetic Energy Problem"<<endl;
        cout<<"Type 6 for Temperature Conversion Problem"<<endl;
        cout<<"Type 7 for Coin Toss Problem"<<endl;
        cout<<"Type 8 for Future Value Problem"<<endl;
        cout<<"Type 9 for Day of the Week Problem"<<endl;
        cout<<"Type any other character to exit"<<endl;
        cin>>choice;

        //Switch to determine the Problem
        switch(choice){
            case '1':{
    //Declare variables
    float cost;  //Inputed cost of item 
    float markup;//Inputed markup percentage
    float retail;//Outputted retail price
    
    //Input data
    cout<<"Please enter the cost of an item"<<endl;
    cin>>cost;
    cout<<"Please enter the markup percentage of the item in %"<<endl;
    cin>>markup; 
    
    //Map inputs to outputs and output the data 
       if(cost>=0&&markup>=0){
    calculateRetail(cost,markup);
       }else{
        cout<<"You did not input a positive number for either the cost"
            <<" or markup percentage. Please try again!!"<<endl;
    }
   
                break;
            }
            case '2':{
    //Declare variables
    float NEsales;
    float SEsales;
    float NWsales;
    float SWsales;
    
    //Initialize variables
    
    //Input data
    
    //Map inputs to outputs or process the data
    for(int i=0;i<4;i++){
        switch (i){
            case 0:
                NEsales=getSales("NE");break;
            case 1:
                SEsales=getSales("SE");break;
            case 2:
                NWsales=getSales("NW");break;
            default: 
                SWsales=getSales("SW");break;
        }
    }
  
    //Output the transformed data
    findHighest(NEsales,SEsales,NWsales,SWsales);
               
                break;
            }
            case '3':{
    //Declare variables
    int accN;
    int accS;
    int accE;
    int accW;
    int accC;
    
    
    //Map inputs to outputs or process the data
    for(int i=0;i<5;i++){
        switch (i){
            case 0:
                accN=getNumAccidents("North");break;
            case 1:
                accS=getNumAccidents("South");break;
            case 2:
                accE=getNumAccidents("East");break;
            case 3: 
                accW=getNumAccidents("West");break;
            default: 
                accC=getNumAccidents("Central");
        }
    }
    
    //Output the transformed data
    findLowest(accN,accS,accE,accW,accC);
               
                break;
            }
            case'4':{
    //Declare and Initialize variables
    int time=0;  //Time it takes for object to hit the ground
    float dist=0;//Distance object has fallen
  
    
    //Map inputs to outputs or process the data
    cout<<"This program calculates the falling distance of an object after "
        <<"10 seconds have passed."<<endl;
    cout<<"Seconds                  Distance (m/s^2)"<<endl;
    cout<<"-----------------------------------"<<endl;
    
    for(int i=1;i<=10;i++){
        dist=fallingDistance(i);
        cout<<i<<"                             "<<dist<<endl;           
    }
    
                
                break;
            }
            case'5':{
    //Declare and Initialize variables
    float ke=0;//Kinetic Energy
    int m=0;   //Object's Mass
    int v=0;   //Object's Velocity
    
    //Map inputs to outputs or process the data
    cout<<"Please enter the object's mass in kg: ";
    cin>>m;
    cout<<"Please enter the speed the object is traveling in m/s :";
    cin>>v;
    
    ke=kineticEnergy(m,v);
    
    //Output the transformed data
    cout<<"The Kinetic Energy of this object is "<<ke<<endl;
   
                break;
            }
            case'6':{
    //Declare and Initialize variables
    float c=0.0f;
    
    //Map inputs to outputs or process the data
    cout<<"This program is used to convert Fahrenheit to Celsius"<<endl;
    cout<<endl;
    cout<<"Fahrenheit                                   Celsius"<<endl;
    cout<<"----------------------------------------------------"<<endl;
    
    for(int i=0;i<21;i++){
        c=celsius(i);
        cout<<i<<"                                         "<<c<<endl;
    }
    
                break;
            }
            case'7':{
    //Random Number Seed
    srand((time(0)));
    //Declare and Initialize variables
   int nTimes=0;
   int randNum=0;
   string headTail="";

    //Map inputs to outputs or process the data
   cout<<"How many times to toss the coin? ";
   cin>>nTimes;
   
    //Output the transformed data
       for(int i=1;i<=nTimes;i++){
       randNum=coinToss();
       if(randNum==1)
           headTail="Head";
       else
           headTail="Tail";
       cout<<headTail<<endl;
   }
   

                break;
            }
            case'8':{
    //Declare variables
    float pv,   //Present Value in $'s
           i;   //Interest rate Percent/compounding period
    int    n;   //Number of compounding periods (yrs)
    
    //Input data - prompt for inputs
    cout<<"This is a Savings Account Program"<<endl;
    cout<<"Input Present Value in Dollars,  "<<endl;
    cout<<"Interest Rate in per cent / year, "<<endl;
    cout<<"Number of Compounding periods in years."<<endl;
    cin>>pv>>i>>n;
    
    //Map the inputs
    i/=CNVPERC;//Convert percentage interest to fraction
    
    //Output the inputs
    cout<<fixed<<setprecision(2)<<showpoint;
    cout<<endl;
    cout<<"The Present Value =  $"<<setw(8)<<pv<<endl;
    cout<<"The Interest Rate =   "<<setw(8)<<i*CNVPERC<<"%"<<endl;
    cout<<"The Number of Years = "<<setw(5)<<n<<endl;
    
    //Output the transformed data
    cout<<"Savings Function 1 -> Power       = $"
            <<fValue1(pv,i,n)<<endl;
    cout<<"Savings Function 1 -> Power Float = $"
            <<fValue1(pv,i,static_cast<float>(n))<<endl;
    cout<<"Savings Function 2 -> Exp - Log   = $"
            <<fValue2(pv,i,n)<<endl;
    cout<<"Savings Function 3 -> for - loop  = $"
            <<fValue3(pv,i,n)<<endl;
    cout<<"Savings Function 4 -> Recursion   = $"
            <<fValue4(pv,i,n)<<endl;
    float fv;
    for(int j=1;j<=5;j++){
        cout<<"Number of Times Function 5 called = "<<fValue5(pv,i,n,fv)<<endl;
    }
    cout<<"Savings Function 5 -> Ref/Static   = $"
            <<fv<<endl;
    cout<<"Savings Function 6 -> Defaulted n=12 $"
            <<fValue6(pv,i,n)<<endl;
    cout<<"Savings Function 6 -> Defaulted n=12 $"
            <<fValue6(pv,i)<<endl;
   
                break;
            }
            case'9':{
    //Declare Variables
    string sMonth;//Month as a string
    string sDay;  //Day as a string 
    short nYear; //Year as an integer
    
    //Input data values
    cout<<"This program takes in a date and returns ";
    cout<<"the day of the week"<<endl;
    cout<<"Input the date in the following format: July 4, 2008"<<endl;
    cin>>sMonth>>sDay>>nYear;
    
    //Process the inputs
    char day=(getDay(sDay)+getMnth(sMonth,nYear)+getYear(nYear)+getCent(nYear))
    %7;
    string msg;
    switch(day){
        case 0:msg="Sunday";break;
        case 1:msg="Monday";break;
        case 2:msg="Tuesday";break;
        case 3:msg="Wednesday";break;
        case 4:msg="Thursday";break;
        case 5:msg="Friday";break;
        default:msg="Saturday";
    }
    cout<<endl<<"Day of the week = "<<msg<<endl;
    //Output the results
 
                break;
            }
            default:
                cout<<"You are exiting the program"<<endl;
        }
    }while(choice>='1'&&choice<='9');
    
    //Exit stage right!
    return 0;
}

void calculateRetail(float cost,float markup){
    float calc;  //First part of calculation
    float retail;//Outputted retail price
    calc=cost*(markup/100);
    retail=cost-calc;
    cout<<"The item's retail price is $"<<retail<<endl;
}

float getSales(string name){
    float sales=0;
    cout<<"Please enter the sales for division "<<name<<" $";
    cin>>sales;
    
    while(sales<0)
    {
        cout<<"Sales cannot be a negative number! Please try again: $";
        cin>>sales;
    }
    return sales;
}

void findHighest(float NEsales,float SEsales,float NWsales,float SWsales){
    float highest=0;
    string division="";
    
    if(NEsales>SEsales&&NEsales>NWsales&&SEsales>SWsales){
        highest=NEsales;
        division="North East";
    }else if(SEsales>NEsales&&SEsales>NWsales&&SEsales>SWsales){
        highest=SEsales;
        division="South East";
        
    }else if(NWsales>NEsales&&NWsales>SEsales&&NWsales>SWsales){
        highest=NWsales;
        division="North West";
    }else{
        highest=SWsales;
        division="South West";
    }
    cout<<"The division with the highest sales is "<<division<<" with the "
        <<"total sales of $"<<highest<<endl;
}

int getNumAccidents(string region){
    int accdnts=0;
    cout<<"Please enter the accidents for region "<<region<<" ";
    cin>>accdnts;
    
    while(accdnts<0)
    {
        cout<<"Accidents cannot be a negative number! Please try again: ";
        cin>>accdnts;
    }
    return accdnts;
}

void findLowest(int r1, int r2, int r3, int r4, int r5){
    int lowest=0;
    string region="";
    
    if(r1<r2&&r1<r3&&r1<r4&&r1<r5){
        lowest=r1;
        region="North";
    }else if(r2<r1&&r2<r3&&r2<r4&&r2<r5){
        lowest=r2;
        region="South";
        
    }else if(r3<r1&&r3<r2&&r3<r4&&r3<r5){
        lowest=r3;
        region="East";
    }else if(r4<r1&&r4<r2&&r4<3&&r4<r5){
        lowest=r4;
        region="West";
    }else{
        lowest=r5;
        region="Central";
    }
    cout<<"The region with the lowest accidents is "<<region<<" with the "
        <<"total accidents being "<<lowest<<endl;
}

float fallingDistance(int t){
    float dist=0;
          dist=(0.5*grav*(pow(t,2)));
return dist;
}

float kineticEnergy(int m,int v){
    return (0.5*m)*(pow(v,2));
}

float celsius (float f){
    float c=0.0f;
    c=(5.0/9)*(f-32);
    
    return c;
}

int coinToss(void){
    int randomNumber;
    randomNumber=1+rand()%2;
    return randomNumber;
}

//000000011111111112222222222333333333344444444445555555555666666666677777777778
//345678901234567890123456789012345678901234567890123456789012345678901234567890
//                     Future Value
//Inputs:
//   pVal ->    Present Value $'s
//   intRate -> Interest Rate as a fraction
//   nPds ->    Number of Compounding Periods (Yrs)
//Output:
//   nTimes ->  Number of times the function was called
//Input/Output:
//   Future Value -> Units of $'s
//000000011111111112222222222333333333344444444445555555555666666666677777777778
//345678901234567890123456789012345678901234567890123456789012345678901234567890
int fValue5(float pVal,float intRate,int nPds,float &fv){
    //Static variable declaration for the count
    static int nTimes=0;
    
    //Calculate the Future Value
    fv=pVal*pow((1+intRate),nPds);
    
    //Return the count
    return ++nTimes;
}

//000000011111111112222222222333333333344444444445555555555666666666677777777778
//345678901234567890123456789012345678901234567890123456789012345678901234567890
//                     Future Value
//Inputs:
//   pVal ->    Present Value $'s
//   intRate -> Interest Rate as a fraction
//   nPds ->    Number of Compounding Periods (Yrs)
//Output:
//   Future Value -> Units of $'s
//000000011111111112222222222333333333344444444445555555555666666666677777777778
//345678901234567890123456789012345678901234567890123456789012345678901234567890
float fValue6(float pVal,float intRate,int nPds){
    return pVal*pow((1+intRate),nPds);
}

float fValue1(float pVal,float intRate,int nPds){
    return pVal*pow((1+intRate),nPds);
}

float fValue1(float pVal,float intRate,float nPds){
    return pVal*pow((1+intRate),nPds);
}

float fValue2(float pVal,float intRate,int nPds){
    return pVal*exp(nPds*log(1+intRate));
}

float fValue3(float pVal,float intRate,int nPds){
    float fv=pVal;
    for(int i=1;i<=nPds;i++){
        fv*=(1+intRate);
    }
    return fv;
}

float fValue4(float pVal,float intRate,int nPds){
    if(nPds<=0)return pVal;
    return fValue4(pVal,intRate,nPds-1)*(1+intRate);
}

 char getDay(string sDay){
     char len=0;
     while(sDay[++len]==',');
     if(len==2)return (sDay[0]-48);
     return (sDay[0]-48)*10+(sDay[1]-48);
 }
     
 char getMnth(string month,int year){
     if(month=="January"){
         if(isLpYr(year))return 6;
         return 0;
     }else if(month=="February"){
         if(isLpYr(year))return 2;
         return 3;
     }else if(month=="March"||month=="November"){
         return 3;
     }else if(month=="April"||month=="July"){
         return 6;
     }else if(month=="May"){
         return 1;
     }else if(month=="June"){
         return 4;
     }else if(month=="August"){
         return 2;
     }else if(month=="September"||month=="December"){
         return 5;
     }else return 0;
 }

char getYear(int year){
    year%=100;
    return year+year/4;
}
char getCent(int year){
    char cent=year/100;
    char remndr=cent%4;
    return 2*(3-remndr);
}
 bool isLpYr(int year){
     return((year%400==0)||((year%4==0)&&!(year%100==0)));
 }